import { defineConfig } from "vite";
import react from "@vitejs/plugin-react";

// Plain Vite + React SPA — ready to import into Lovable.
export default defineConfig({
  plugins: [react()],
  server: { allowedHosts: true },
  preview: { allowedHosts: true },
  build: {
    outDir: "dist",
    sourcemap: false,
  },
});
